
import React from 'react';
import { motion } from 'framer-motion';
import { Home, Map, MessageCircle, Users, HelpCircle, User, MessageSquare } from 'lucide-react';

const BottomNav = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'home', icon: Home, label: 'Feed' },
    { id: 'messages', icon: MessageCircle, label: 'Chat' },
    { id: 'qna', icon: HelpCircle, label: 'Q&A' },
    { id: 'communities', icon: Users, label: 'Groups' },
    { id: 'map', icon: Map, label: 'Map' },
    { id: 'profile', icon: User, label: 'Me' }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)] border-t border-gray-100 z-50">
      <div className="flex justify-around items-center h-20 w-full px-2 pb-2 overflow-x-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          
          return (
            <motion.button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className="flex flex-col items-center justify-center min-w-[60px] h-full relative"
              whileTap={{ scale: 0.9 }}
            >
              <motion.div
                animate={{
                  y: isActive ? -5 : 0,
                  color: isActive ? '#9CAF88' : '#9CA3AF'
                }}
                className={`p-2 rounded-full ${isActive ? 'bg-[#F5F9F2]' : 'bg-transparent'}`}
              >
                <Icon className={isActive ? "w-5 h-5 fill-current" : "w-5 h-5"} />
              </motion.div>
              <span className={`text-[9px] font-medium ${isActive ? 'text-[#9CAF88]' : 'text-gray-400'}`}>
                {tab.label}
              </span>
            </motion.button>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;
