
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, Bot, User, Settings as SettingsIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/components/ui/use-toast';

const AIAssistant = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [chatHistory, setChatHistory] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [chatHistory]);

  const handleSend = async () => {
    if (!message.trim()) return;
    
    // Check for API Key
    const apiKey = user?.openai_api_key || localStorage.getItem('openai_api_key');
    if (!apiKey) {
      toast({
        title: "API Key Missing",
        description: "Please add your OpenAI API Key in Settings to use the AI Assistant.",
        variant: "destructive"
      });
      return;
    }

    const userMessage = { role: 'user', content: message, timestamp: new Date().toLocaleTimeString() };
    setChatHistory(prev => [...prev, userMessage]);
    setMessage('');
    setIsLoading(true);

    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-3.5-turbo',
          messages: [
            { role: 'system', content: 'You are Paws AI, a helpful and knowledgeable pet care assistant. Provide advice on pet health, training, nutrition, and behavior. Keep answers concise and friendly.' },
            ...chatHistory.map(msg => ({ role: msg.role, content: msg.content })),
            { role: 'user', content: message }
          ]
        })
      });

      if (!response.ok) {
        throw new Error('API Request Failed');
      }

      const data = await response.json();
      const botMessage = {
        role: 'assistant',
        content: data.choices[0].message.content,
        timestamp: new Date().toLocaleTimeString()
      };
      setChatHistory(prev => [...prev, botMessage]);

    } catch (error) {
      console.error(error);
      toast({
        title: "AI Error",
        description: "Failed to get response from AI. Check your API Key.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) return null;

  return (
    <>
      <motion.button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-24 right-6 w-16 h-16 rounded-full shadow-2xl flex items-center justify-center z-40 bg-[#B4D4FF] hover:bg-[#9ec5f7] transition-colors"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
      >
        <Bot className="w-8 h-8 text-[#1a1b1e]" />
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 100 }}
            className="fixed bottom-24 right-6 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl z-50 overflow-hidden border border-gray-100"
          >
            {/* Header */}
            <div className="p-4 flex items-center justify-between bg-[#B4D4FF]">
              <div className="flex items-center gap-2">
                <Bot className="w-6 h-6 text-[#1a1b1e]" />
                <span className="font-bold text-[#1a1b1e]" style={{ fontFamily: 'Poppins, sans-serif' }}>
                  Paws AI
                </span>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-[#1a1b1e] hover:bg-white/20 rounded-full p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Chat Area */}
            <div ref={scrollRef} className="h-96 overflow-y-auto p-4 space-y-4 bg-[#FFF8F3]">
              {chatHistory.length === 0 && (
                <div className="text-center py-8 opacity-70">
                  <Bot className="w-12 h-12 mx-auto mb-2 text-gray-400" />
                  <p className="text-sm">Ask me anything about your pet!</p>
                </div>
              )}
              
              {chatHistory.map((msg, index) => (
                <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                   <div className={`max-w-[85%] p-3 rounded-2xl ${
                     msg.role === 'user' 
                       ? 'bg-[#9CAF88] text-white rounded-br-none' 
                       : 'bg-white text-gray-800 shadow-sm rounded-bl-none'
                   }`}>
                     <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                     <span className="text-[10px] opacity-70 mt-1 block text-right">{msg.timestamp}</span>
                   </div>
                </div>
              ))}
              
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-white p-3 rounded-2xl rounded-bl-none shadow-sm">
                    <div className="flex gap-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Input Area */}
            <div className="p-4 bg-white border-t border-gray-100">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Type a message..."
                  className="flex-1 px-4 py-2 rounded-full border border-gray-200 focus:outline-none focus:border-[#9CAF88] bg-gray-50 text-sm"
                />
                <Button 
                  onClick={handleSend} 
                  disabled={isLoading || !message.trim()}
                  className="rounded-full w-10 h-10 p-0"
                  style={{ backgroundColor: '#9CAF88' }}
                >
                  <Send className="w-4 h-4 text-white" />
                </Button>
              </div>
              {!user?.openai_api_key && !localStorage.getItem('openai_api_key') && (
                 <p className="text-xs text-red-500 mt-2 text-center">
                   API Key required. Go to Settings.
                 </p>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default AIAssistant;
