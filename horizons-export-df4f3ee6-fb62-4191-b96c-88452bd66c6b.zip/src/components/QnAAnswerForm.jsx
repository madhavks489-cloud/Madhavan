
import React, { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/components/ui/use-toast';

const QnAAnswerForm = ({ questionId, onAnswerSubmitted }) => {
  const { user } = useAuth();
  const [content, setContent] = useState('');
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!content.trim()) return;

    const { error } = await supabase.from('qna_answers').insert({
      question_id: questionId,
      author_id: user.id,
      content
    });

    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Answer Posted", description: "Thank you, Doctor!" });
      setContent('');
      onAnswerSubmitted();
    }
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg border-2 border-[#D4AF37]">
      <h3 className="font-bold text-[#D4AF37] mb-4">Post Expert Answer</h3>
      <textarea
        value={content}
        onChange={e => setContent(e.target.value)}
        className="w-full p-4 bg-yellow-50 rounded-lg mb-4 min-h-[120px] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
        placeholder="Write your professional medical advice..."
      />
      <div className="flex justify-end">
        <Button onClick={handleSubmit} className="bg-[#D4AF37] hover:bg-[#b5952f] text-white">
          Submit Answer
        </Button>
      </div>
    </div>
  );
};

export default QnAAnswerForm;
