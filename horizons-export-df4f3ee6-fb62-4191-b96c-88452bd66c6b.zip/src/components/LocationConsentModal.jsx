
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MapPin, Shield, Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const LocationConsentModal = ({ isOpen, onAccept, onDecline }) => {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl"
        >
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-[#FFF8F3] rounded-full flex items-center justify-center mx-auto mb-4">
              <MapPin className="w-8 h-8 text-[#9CAF88]" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Enable Location?
            </h2>
            <p className="text-gray-600 mb-4" style={{ fontFamily: 'Inter, sans-serif' }}>
              We use your location to show you nearby parks, vets, and pet friends.
            </p>
            
            <div className="bg-gray-50 rounded-xl p-4 text-left text-sm text-gray-600 mb-6 flex items-start gap-3">
              <Shield className="w-5 h-5 text-[#9CAF88] flex-shrink-0" />
              <p>Your privacy is important. We only show your approximate location to other verified users.</p>
            </div>
          </div>

          <div className="space-y-3">
            <Button
              onClick={onAccept}
              className="w-full py-6 rounded-xl text-lg"
              style={{ backgroundColor: '#9CAF88', color: 'white' }}
            >
              <Check className="w-5 h-5 mr-2" /> Allow Location Access
            </Button>
            <Button
              onClick={onDecline}
              variant="ghost"
              className="w-full py-6 rounded-xl text-gray-500 hover:text-gray-900"
            >
              <X className="w-5 h-5 mr-2" /> Not Now
            </Button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default LocationConsentModal;
