
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Heart, Star, Lock, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const LandingPage = ({ onEnter }) => {
  const features = [
    {
      icon: <Heart className="w-8 h-8" />,
      title: 'Connect with Pet Lovers',
      description: 'Share moments, make friends, and build a community of pet enthusiasts'
    },
    {
      icon: <Star className="w-8 h-8" />,
      title: 'Expert Advice',
      description: 'Get professional tips from certified vets and trainers'
    },
    {
      icon: <Lock className="w-8 h-8" />,
      title: 'Pet Health Vault',
      description: 'Securely store and manage your pet\'s health records'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Paws & Pals - The Ultimate Pet Community</title>
        <meta name="description" content="Join Paws & Pals, the social network for pet lovers. Connect with other pet parents, get expert advice, and manage your pet's health records all in one place." />
      </Helmet>
      
      <div className="min-h-screen" style={{ backgroundColor: '#FFF8F3' }}>
        {/* Hero Section */}
        <section className="container mx-auto px-4 py-16 md:py-24">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, ease: 'easeOut' }}
            >
              <h1 className="text-5xl md:text-6xl font-bold mb-6 text-gray-900" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Welcome to <br />
                <span style={{ color: '#9CAF88' }}>Paws & Pals</span>
              </h1>
              <p className="text-xl md:text-2xl text-gray-600 mb-8" style={{ fontFamily: 'Inter, sans-serif' }}>
                Where every tail wags, every whisker twitches, and every pet parent finds their community
              </p>
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                transition={{ type: 'spring', stiffness: 400, damping: 17 }}
              >
                <Button
                  onClick={onEnter}
                  className="text-lg px-8 py-6 rounded-full shadow-lg"
                  style={{ 
                    backgroundColor: '#B4D4FF',
                    color: '#1a1b1e'
                  }}
                >
                  Enter the App <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </motion.div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, ease: 'easeOut', delay: 0.2 }}
              className="rounded-3xl overflow-hidden shadow-2xl"
            >
              <img
                src="https://images.unsplash.com/photo-1610712728698-21eb15759806"
                alt="Happy Golden Retriever"
                className="w-full h-[400px] md:h-[500px] object-cover"
              />
            </motion.div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16 md:py-24">
          <div className="container mx-auto px-4">
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-4xl md:text-5xl font-bold text-center mb-16 text-gray-900"
              style={{ fontFamily: 'Poppins, sans-serif' }}
            >
              Everything Your Pet Needs
            </motion.h2>
            
            <div className="grid md:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  whileHover={{ y: -10, transition: { duration: 0.3 } }}
                  className="bg-white p-8 rounded-3xl shadow-lg"
                >
                  <div
                    className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6"
                    style={{ backgroundColor: '#9CAF88', color: '#FFF8F3' }}
                  >
                    {feature.icon}
                  </div>
                  <h3 className="text-2xl font-bold mb-4 text-gray-900" style={{ fontFamily: 'Poppins, sans-serif' }}>
                    {feature.title}
                  </h3>
                  <p className="text-gray-600" style={{ fontFamily: 'Inter, sans-serif' }}>
                    {feature.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 md:py-24">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="container mx-auto px-4 text-center"
          >
            <div className="bg-white p-12 md:p-16 rounded-3xl shadow-2xl max-w-3xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Ready to Join Our Community?
              </h2>
              <p className="text-xl text-gray-600 mb-8" style={{ fontFamily: 'Inter, sans-serif' }}>
                Connect with thousands of pet lovers, share your pet's adventures, and get expert advice
              </p>
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                transition={{ type: 'spring', stiffness: 400, damping: 17 }}
              >
                <Button
                  onClick={onEnter}
                  className="text-lg px-10 py-6 rounded-full shadow-lg"
                  style={{ 
                    backgroundColor: '#B4D4FF',
                    color: '#1a1b1e'
                  }}
                >
                  Get Started Now <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </motion.div>
            </div>
          </motion.div>
        </section>
      </div>
    </>
  );
};

export default LandingPage;
