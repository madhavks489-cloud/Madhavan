
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, ChevronUp, ChevronDown, Flag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

const ThreadPost = ({ post }) => {
  const [upvoted, setUpvoted] = useState(false);
  const [downvoted, setDownvoted] = useState(false);
  const [votes, setVotes] = useState(post.upvotes);
  const { toast } = useToast();

  const handleUpvote = () => {
    if (upvoted) {
      setVotes(votes - 1);
      setUpvoted(false);
    } else {
      if (downvoted) {
        setVotes(votes + 2);
        setDownvoted(false);
      } else {
        setVotes(votes + 1);
      }
      setUpvoted(true);
    }
  };

  const handleDownvote = () => {
    if (downvoted) {
      setVotes(votes + 1);
      setDownvoted(false);
    } else {
      if (upvoted) {
        setVotes(votes - 2);
        setUpvoted(false);
      } else {
        setVotes(votes - 1);
      }
      setDownvoted(true);
    }
  };

  const handleComment = () => {
    toast({
      title: "🚧 Coming Soon!",
      description: "Comment feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  const handleReport = () => {
    toast({
      title: "Report Submitted",
      description: "Thank you for helping keep our community safe. We'll review this post.",
    });
  };

  return (
    <motion.div
      whileHover={{ y: -2 }}
      transition={{ duration: 0.2 }}
      className="bg-white rounded-xl shadow-lg p-4"
    >
      <div className="flex gap-4">
        {/* Vote Section */}
        <div className="flex flex-col items-center gap-1">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={handleUpvote}
            className={`p-1 rounded ${upvoted ? 'text-green-600' : 'text-gray-400'}`}
          >
            <ChevronUp className="w-6 h-6" />
          </motion.button>
          <span className="font-bold text-gray-900" style={{ fontFamily: 'Inter, sans-serif' }}>
            {votes}
          </span>
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={handleDownvote}
            className={`p-1 rounded ${downvoted ? 'text-red-600' : 'text-gray-400'}`}
          >
            <ChevronDown className="w-6 h-6" />
          </motion.button>
        </div>

        {/* Content Section */}
        <div className="flex-1">
          <div className="flex items-start justify-between mb-2">
            <div className="flex items-center gap-2">
              <img
                src={post.user.avatar}
                alt={post.user.name}
                className="w-8 h-8 rounded-full"
              />
              <div>
                <span className="font-semibold text-gray-900 text-sm" style={{ fontFamily: 'Inter, sans-serif' }}>
                  {post.user.name}
                </span>
                <span className="text-xs text-gray-500 ml-2">{post.timestamp}</span>
              </div>
            </div>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="ghost" size="sm">
                  <Flag className="w-4 h-4 text-gray-500" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Report this thread?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to report this thread? Our team will review it.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleReport}>Report</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>

          <h3 className="text-lg font-bold text-gray-900 mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
            {post.title}
          </h3>
          <p className="text-gray-700 mb-3" style={{ fontFamily: 'Inter, sans-serif' }}>
            {post.content}
          </p>

          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={handleComment}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
          >
            <MessageCircle className="w-5 h-5" />
            <span className="text-sm font-semibold">{post.comments} comments</span>
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
};

export default ThreadPost;
