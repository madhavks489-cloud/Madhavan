
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Heart, MessageCircle, Flag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

const FeedPost = ({ post }) => {
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(post.likes);
  const { toast } = useToast();

  const handleLike = () => {
    if (liked) {
      setLikeCount(likeCount - 1);
      setLiked(false);
    } else {
      setLikeCount(likeCount + 1);
      setLiked(true);
    }
  };

  const handleComment = () => {
    toast({
      title: "🚧 Coming Soon!",
      description: "Comment feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  const handleReport = () => {
    toast({
      title: "Report Submitted",
      description: "Thank you for helping keep our community safe. We'll review this post.",
    });
  };

  return (
    <motion.div
      whileHover={{ y: -2 }}
      transition={{ duration: 0.2 }}
      className="bg-white rounded-xl shadow-lg overflow-hidden"
    >
      {/* Header */}
      <div className="p-4 flex items-center gap-3">
        <img
          src={post.pet.photo_url}
          alt={post.pet.name}
          className="w-12 h-12 rounded-full object-cover border-2"
          style={{ borderColor: '#9CAF88' }}
        />
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className="font-bold text-gray-900" style={{ fontFamily: 'Poppins, sans-serif' }}>
              {post.pet.name}
            </span>
            {post.pet.verified && (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="#D4AF37">
                <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" />
              </svg>
            )}
          </div>
          <span className="text-sm text-gray-500" style={{ fontFamily: 'Inter, sans-serif' }}>
            {post.pet.breed} • {post.timestamp}
          </span>
        </div>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="ghost" size="sm">
              <Flag className="w-4 h-4 text-gray-500" />
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Report this post?</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to report this post? Our team will review it.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleReport}>Report</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>

      {/* Image */}
      <img
        src={post.image_url}
        alt={post.content}
        className="w-full h-80 object-cover"
      />

      {/* Actions */}
      <div className="p-4">
        <div className="flex items-center gap-4 mb-3">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={handleLike}
            className="flex items-center gap-2"
          >
            <Heart
              className={`w-6 h-6 ${liked ? 'fill-red-500 text-red-500' : 'text-gray-600'}`}
            />
            <span className="text-sm font-semibold text-gray-900">{likeCount}</span>
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={handleComment}
            className="flex items-center gap-2"
          >
            <MessageCircle className="w-6 h-6 text-gray-600" />
            <span className="text-sm font-semibold text-gray-900">{post.comments}</span>
          </motion.button>
        </div>

        {/* Content */}
        <p className="text-gray-800" style={{ fontFamily: 'Inter, sans-serif' }}>
          <span className="font-bold">{post.pet.name}</span> {post.content}
        </p>
      </div>
    </motion.div>
  );
};

export default FeedPost;
