
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Settings, LogOut, Plus, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import SettingsPanel from '@/components/SettingsPanel';
import AddPetPage from '@/components/AddPetPage';
import LostFoundPage from '@/components/LostFoundPage';

const Profile = () => {
  const [view, setView] = useState('main'); // main, settings, add-pet, lost-found
  const { user, logout } = useAuth();
  const [myPets, setMyPets] = useState([]);

  useEffect(() => {
    // Load pets from local storage for simulation
    const storedPets = JSON.parse(localStorage.getItem('paws_pets') || '[]');
    setMyPets(storedPets.filter(p => p.owner_id === user?.id));
  }, [user, view]);

  if (view === 'settings') return <SettingsPanel onBack={() => setView('main')} />;
  if (view === 'add-pet') return <AddPetPage onBack={() => setView('main')} />;
  if (view === 'lost-found') return <LostFoundPage onBack={() => setView('main')} />;

  return (
    <div className="container mx-auto px-4 py-6 max-w-2xl">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-gray-900 font-poppins">Profile</h1>
        <button onClick={() => setView('settings')}>
          <Settings className="w-6 h-6 text-gray-600" />
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-lg p-6 mb-6 flex items-center gap-4">
         <div className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center text-2xl font-bold text-gray-400">
           {user?.name?.[0].toUpperCase()}
         </div>
         <div>
           <h2 className="text-2xl font-bold">{user?.name}</h2>
           <p className="text-gray-500">{user?.email}</p>
         </div>
      </div>

      <div className="flex gap-4 mb-8">
         <Button 
           onClick={() => setView('add-pet')}
           className="flex-1 py-6 bg-[#9CAF88] hover:bg-[#8b9c79]"
         >
           <Plus className="w-5 h-5 mr-2" /> Add Pet
         </Button>
         <Button 
           onClick={() => setView('lost-found')}
           variant="outline"
           className="flex-1 py-6 border-red-200 text-red-600 hover:bg-red-50"
         >
           <AlertTriangle className="w-5 h-5 mr-2" /> Report Lost
         </Button>
      </div>

      <h2 className="text-xl font-bold mb-4">My Pets</h2>
      {myPets.length === 0 ? (
        <div className="text-center py-8 bg-gray-50 rounded-xl border border-dashed border-gray-300">
           <p className="text-gray-500 mb-4">No pets added yet.</p>
           <Button variant="link" onClick={() => setView('add-pet')}>Add your first pet</Button>
        </div>
      ) : (
        <div className="grid gap-4">
          {myPets.map(pet => (
            <div key={pet.id} className="bg-white p-4 rounded-xl shadow flex items-center gap-4">
               <img src={pet.photo_url} alt={pet.name} className="w-16 h-16 rounded-full object-cover" />
               <div>
                 <h3 className="font-bold">{pet.name}</h3>
                 <p className="text-sm text-gray-500">{pet.breed} • {pet.age}</p>
               </div>
            </div>
          ))}
        </div>
      )}

      <Button onClick={logout} variant="ghost" className="w-full mt-8 text-red-500 hover:text-red-700 hover:bg-red-50">
        <LogOut className="w-4 h-4 mr-2" /> Logout
      </Button>
    </div>
  );
};

export default Profile;
