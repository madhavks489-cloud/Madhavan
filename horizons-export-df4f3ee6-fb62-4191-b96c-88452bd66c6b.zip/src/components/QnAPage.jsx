
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { HelpCircle, ThumbsUp, Check, Plus, Filter } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import QnAAnswerForm from './QnAAnswerForm';

const QnAPage = () => {
  const { user } = useAuth();
  const [questions, setQuestions] = useState([]);
  const [activeQuestion, setActiveQuestion] = useState(null);
  const [showAskForm, setShowAskForm] = useState(false);

  useEffect(() => {
    fetchQuestions();
    const channel = supabase
      .channel('public:qna')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'qna_questions' }, fetchQuestions)
      .subscribe();
    return () => supabase.removeChannel(channel);
  }, []);

  const fetchQuestions = async () => {
    const { data } = await supabase
      .from('qna_questions')
      .select('*, profiles:author_id(full_name), qna_answers(*)')
      .order('created_at', { ascending: false });
    if (data) setQuestions(data);
  };

  if (activeQuestion) {
    return (
      <div className="container mx-auto px-4 py-6 max-w-2xl min-h-screen">
        <Button variant="ghost" onClick={() => setActiveQuestion(null)} className="mb-4 pl-0">
          ← Back to Questions
        </Button>
        <div className="bg-white p-6 rounded-xl shadow-lg mb-6">
          <h1 className="text-2xl font-bold mb-2 font-poppins">{activeQuestion.title}</h1>
          <p className="text-gray-600 mb-4">{activeQuestion.description}</p>
          {activeQuestion.pet_photo_url && (
             <img src={activeQuestion.pet_photo_url} alt="Pet" className="w-full h-64 object-cover rounded-lg mb-4" />
          )}
          <div className="flex justify-between text-sm text-gray-500">
             <span>Asked by {activeQuestion.profiles?.full_name || 'Anonymous'}</span>
             <span className="bg-blue-50 text-blue-600 px-2 py-1 rounded">{activeQuestion.category}</span>
          </div>
        </div>

        <h3 className="font-bold text-lg mb-4">Expert Answers ({activeQuestion.qna_answers?.length || 0})</h3>
        
        {/* Answers List */}
        <div className="space-y-4 mb-8">
           {/* In a real implementation, we would fetch answers joined with profiles here */}
           <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-xl">
             <div className="flex items-center gap-2 mb-2">
               <span className="font-bold text-[#D4AF37]">Dr. Smith</span>
               <div className="px-2 py-0.5 bg-[#D4AF37] text-white text-[10px] rounded-full uppercase font-bold">Verified Vet</div>
             </div>
             <p className="text-gray-800">This is a placeholder for actual answers fetched from Supabase.</p>
           </div>
        </div>

        {user?.role === 'verified_vet' && (
           <QnAAnswerForm questionId={activeQuestion.id} onAnswerSubmitted={fetchQuestions} />
        )}
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6 max-w-2xl min-h-screen pb-24">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold font-poppins text-gray-900">Vet Q&A</h1>
          <p className="text-gray-500 text-sm">Get answers from verified experts</p>
        </div>
        <Button onClick={() => setShowAskForm(true)} className="bg-[#D4AF37] hover:bg-[#b5952f] text-white">
          <Plus className="w-4 h-4 mr-1" /> Ask
        </Button>
      </div>

      <div className="space-y-4">
        {questions.map(q => (
          <motion.div
            key={q.id}
            onClick={() => setActiveQuestion(q)}
            whileHover={{ y: -2 }}
            className="bg-white p-5 rounded-xl shadow-sm border border-gray-100 cursor-pointer relative overflow-hidden"
          >
            {q.is_solved && (
              <div className="absolute top-0 right-0 bg-green-500 text-white px-2 py-1 text-xs font-bold rounded-bl-xl">
                SOLVED
              </div>
            )}
            <h3 className="font-bold text-lg text-gray-900 mb-2">{q.title}</h3>
            <p className="text-gray-600 text-sm line-clamp-2 mb-3">{q.description}</p>
            <div className="flex items-center gap-4 text-xs text-gray-500">
               <span className="flex items-center gap-1"><HelpCircle className="w-3 h-3" /> {q.qna_answers?.length || 0} answers</span>
               <span className="bg-gray-100 px-2 py-0.5 rounded uppercase">{q.category}</span>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default QnAPage;
