
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, MapPin, Key, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/components/ui/use-toast';

const SettingsPanel = ({ onBack }) => {
  const { user, updateUser } = useAuth();
  const [apiKey, setApiKey] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    // Load existing key from localStorage if exists
    const storedKey = localStorage.getItem('openai_api_key');
    if (storedKey) setApiKey(storedKey);
    else if (user?.openai_api_key) setApiKey(user.openai_api_key);
  }, [user]);

  const handleSaveKey = () => {
    // In real app, encrypt this. For prototype, use localStorage.
    localStorage.setItem('openai_api_key', apiKey);
    updateUser({ openai_api_key: apiKey });
    toast({
      title: "Settings Saved",
      description: "API Key updated successfully.",
    });
  };

  const toggleLocation = () => {
    updateUser({ location_sharing: !user.location_sharing });
  };

  return (
    <div className="container mx-auto px-4 py-6 max-w-2xl">
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
      >
        <button onClick={onBack} className="flex items-center gap-2 mb-6 text-gray-600 hover:text-gray-900">
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Profile</span>
        </button>

        <h1 className="text-3xl font-bold mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>Settings</h1>

        <div className="space-y-6">
          {/* Location Toggle */}
          <div className="bg-white rounded-xl shadow-lg p-6 flex justify-between items-center">
             <div className="flex gap-3">
               <MapPin className="w-6 h-6 text-[#9CAF88]" />
               <div>
                 <Label className="text-lg font-semibold">Location Sharing</Label>
                 <p className="text-sm text-gray-500">Show my location on map</p>
               </div>
             </div>
             <button
                onClick={toggleLocation}
                className={`relative w-14 h-8 rounded-full transition-colors ${
                  user.location_sharing ? 'bg-green-500' : 'bg-gray-300'
                }`}
              >
                <div className={`absolute top-1 w-6 h-6 bg-white rounded-full shadow transition-transform ${
                  user.location_sharing ? 'translate-x-7' : 'translate-x-1'
                }`} />
              </button>
          </div>

          {/* OpenAI API Key */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center gap-3 mb-4">
              <Key className="w-6 h-6 text-[#B4D4FF]" />
              <Label className="text-lg font-semibold">OpenAI API Key</Label>
            </div>
            <p className="text-sm text-gray-500 mb-4">Required for AI Assistant functionality.</p>
            <div className="flex gap-2">
              <input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="sk-..."
                className="flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-[#B4D4FF]"
              />
              <Button onClick={handleSaveKey} variant="outline">
                <Save className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default SettingsPanel;
