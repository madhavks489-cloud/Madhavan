
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, Heart, Bone, Brain, Activity, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ForumThread from './ForumThread';
import CreateThreadForm from './CreateThreadForm';

const categories = [
  { id: 'health', name: 'Pet Health', icon: Activity, color: '#FFB4B4' },
  { id: 'nutrition', name: 'Nutrition', icon: Bone, color: '#B4D4FF' },
  { id: 'behavior', name: 'Behavior', icon: Brain, color: '#FFE4B4' },
  { id: 'general', name: 'General Chat', icon: MessageSquare, color: '#9CAF88' },
];

const ForumPage = () => {
  const [activeCategory, setActiveCategory] = useState(null);
  const [activeThreadId, setActiveThreadId] = useState(null);
  const [isCreating, setIsCreating] = useState(false);

  if (activeThreadId) {
    return <ForumThread threadId={activeThreadId} onBack={() => setActiveThreadId(null)} />;
  }

  if (isCreating) {
    return <CreateThreadForm categoryId={activeCategory} onBack={() => setIsCreating(false)} />;
  }

  // Mock threads stored in localStorage
  const threads = JSON.parse(localStorage.getItem('forum_threads') || '[]')
    .filter(t => !activeCategory || t.category === activeCategory);

  return (
    <div className="container mx-auto px-4 py-6 max-w-2xl min-h-screen pb-24">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold font-poppins">Community Forum</h1>
        <Button onClick={() => setIsCreating(true)} className="bg-[#9CAF88]">
          <Plus className="w-4 h-4 mr-2" /> New Topic
        </Button>
      </div>

      {/* Category Pills */}
      <div className="flex gap-3 overflow-x-auto pb-4 mb-4 no-scrollbar">
        <button
          onClick={() => setActiveCategory(null)}
          className={`px-4 py-2 rounded-full whitespace-nowrap transition-colors ${
            !activeCategory ? 'bg-gray-800 text-white' : 'bg-white text-gray-600'
          }`}
        >
          All Topics
        </button>
        {categories.map(cat => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-4 py-2 rounded-full whitespace-nowrap transition-colors flex items-center gap-2 ${
              activeCategory === cat.id ? `bg-[${cat.color}] text-gray-900 font-bold` : 'bg-white text-gray-600'
            }`}
            style={activeCategory === cat.id ? { backgroundColor: cat.color } : {}}
          >
            <cat.icon className="w-3 h-3" />
            {cat.name}
          </button>
        ))}
      </div>

      {/* Thread List */}
      <div className="space-y-4">
        {threads.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl shadow-sm">
            <MessageSquare className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500">No discussions yet. Start one!</p>
          </div>
        ) : (
          threads.map(thread => (
            <motion.div
              key={thread.id}
              whileHover={{ y: -2 }}
              onClick={() => setActiveThreadId(thread.id)}
              className="bg-white p-5 rounded-xl shadow-sm border border-gray-100 cursor-pointer"
            >
              <div className="flex justify-between items-start mb-2">
                <span className="text-xs font-semibold px-2 py-1 rounded bg-gray-100 text-gray-600 uppercase">
                  {thread.category}
                </span>
                <span className="text-xs text-gray-400">{new Date(thread.createdAt).toLocaleDateString()}</span>
              </div>
              <h3 className="font-bold text-lg text-gray-900 mb-2">{thread.title}</h3>
              <p className="text-gray-600 text-sm line-clamp-2 mb-3">{thread.content}</p>
              <div className="flex items-center gap-4 text-xs text-gray-500">
                <span className="flex items-center gap-1"><Heart className="w-3 h-3" /> {thread.likes || 0}</span>
                <span className="flex items-center gap-1"><MessageSquare className="w-3 h-3" /> {thread.comments?.length || 0} comments</span>
                <span>by {thread.authorName}</span>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
};

export default ForumPage;
