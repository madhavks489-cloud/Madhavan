
import React from 'react';
import { motion } from 'framer-motion';
import { Camera } from 'lucide-react';
import FeedPost from '@/components/FeedPost';
import ThreadPost from '@/components/ThreadPost';

const Feed = () => {
  // Normally fetch from DB, now empty
  const posts = []; 

  return (
    <div className="container mx-auto px-4 py-6 max-w-2xl min-h-[50vh]">
      <motion.h1
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-3xl font-bold mb-6 text-gray-900"
        style={{ fontFamily: 'Poppins, sans-serif' }}
      >
        Your Feed
      </motion.h1>

      {posts.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl shadow-sm border border-gray-100">
           <div className="w-16 h-16 bg-[#FFF8F3] rounded-full flex items-center justify-center mx-auto mb-4">
             <Camera className="w-8 h-8 text-[#9CAF88]" />
           </div>
           <h3 className="text-xl font-bold text-gray-800 mb-2">No posts yet</h3>
           <p className="text-gray-500 max-w-xs mx-auto">
             Be the first to share a photo of your furry friend or start a discussion!
           </p>
        </div>
      ) : (
        <div className="space-y-6">
          {posts.map(post => (
             post.type === 'photo' ? <FeedPost key={post.id} post={post} /> : <ThreadPost key={post.id} post={post} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Feed;
