
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Heart, MessageCircle, Flag, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

const ExpertPost = ({ post }) => {
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(post.likes);
  const { toast } = useToast();

  const handleLike = () => {
    if (liked) {
      setLikeCount(likeCount - 1);
      setLiked(false);
    } else {
      setLikeCount(likeCount + 1);
      setLiked(true);
    }
  };

  const handleComment = () => {
    toast({
      title: "🚧 Coming Soon!",
      description: "Comment feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  const handleReport = () => {
    toast({
      title: "Report Submitted",
      description: "Thank you for your feedback. We'll review this post.",
    });
  };

  return (
    <motion.div
      whileHover={{ y: -2 }}
      transition={{ duration: 0.2 }}
      className="bg-white rounded-xl shadow-lg overflow-hidden"
    >
      {/* Header */}
      <div className="p-4 flex items-center gap-3">
        <img
          src={post.expert.avatar}
          alt={post.expert.name}
          className="w-12 h-12 rounded-full object-cover"
        />
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className="font-bold text-gray-900" style={{ fontFamily: 'Poppins, sans-serif' }}>
              {post.expert.name}
            </span>
            {post.expert.verified && (
              <div className="flex items-center justify-center w-5 h-5 bg-yellow-400 rounded-full">
                <Star className="w-3 h-3 text-white fill-white" />
              </div>
            )}
          </div>
          <span className="text-xs text-gray-600" style={{ fontFamily: 'Inter, sans-serif' }}>
            {post.expert.credentials}
          </span>
        </div>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="ghost" size="sm">
              <Flag className="w-4 h-4 text-gray-500" />
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Report this expert post?</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to report this post? Our team will review it.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleReport}>Report</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>

      {/* Image */}
      <img
        src={post.image_url}
        alt={post.title}
        className="w-full h-64 object-cover"
      />

      {/* Content */}
      <div className="p-4">
        <h2 className="text-xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
          {post.title}
        </h2>
        <p className="text-gray-700 mb-4 line-clamp-3" style={{ fontFamily: 'Inter, sans-serif' }}>
          {post.content}
        </p>

        {/* Actions */}
        <div className="flex items-center gap-4 pt-2 border-t border-gray-100">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={handleLike}
            className="flex items-center gap-2"
          >
            <Heart
              className={`w-5 h-5 ${liked ? 'fill-red-500 text-red-500' : 'text-gray-600'}`}
            />
            <span className="text-sm font-semibold text-gray-900">{likeCount}</span>
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={handleComment}
            className="flex items-center gap-2"
          >
            <MessageCircle className="w-5 h-5 text-gray-600" />
            <span className="text-sm text-gray-600">Comment</span>
          </motion.button>
          <span className="text-xs text-gray-500 ml-auto">{post.timestamp}</span>
        </div>
      </div>
    </motion.div>
  );
};

export default ExpertPost;
