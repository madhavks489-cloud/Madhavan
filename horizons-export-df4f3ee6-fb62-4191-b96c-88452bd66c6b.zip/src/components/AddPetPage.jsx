
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Camera, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/context/AuthContext';

const AddPetPage = ({ onBack }) => {
  const [name, setName] = useState('');
  const [breed, setBreed] = useState('');
  const [age, setAge] = useState('');
  const { toast } = useToast();
  const { user } = useAuth();

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Simulate saving to DB
    const newPet = {
      id: Date.now().toString(),
      name,
      breed,
      age,
      photo_url: 'https://images.unsplash.com/photo-1543466835-00a7907e9de1',
      owner_id: user.id
    };

    const existingPets = JSON.parse(localStorage.getItem('paws_pets') || '[]');
    localStorage.setItem('paws_pets', JSON.stringify([...existingPets, newPet]));

    toast({
      title: "Success!",
      description: `${name} has been added to your family.`,
    });
    onBack();
  };

  return (
    <div className="container mx-auto px-4 py-6 max-w-md">
      <button onClick={onBack} className="flex items-center gap-2 mb-6 text-gray-600">
        <ArrowLeft className="w-5 h-5" /> Back
      </button>

      <h1 className="text-2xl font-bold mb-6">Add New Pet</h1>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="bg-gray-100 h-48 rounded-xl flex flex-col items-center justify-center border-2 border-dashed border-gray-300 cursor-pointer hover:bg-gray-200 transition">
          <Camera className="w-8 h-8 text-gray-400 mb-2" />
          <span className="text-sm text-gray-500">Upload Photo</span>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Pet Name</label>
          <input 
            required
            value={name}
            onChange={e => setName(e.target.value)}
            className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-[#9CAF88] outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Breed</label>
          <input 
            required
            value={breed}
            onChange={e => setBreed(e.target.value)}
            className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-[#9CAF88] outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Age</label>
          <input 
            required
            value={age}
            onChange={e => setAge(e.target.value)}
            placeholder="e.g. 2 years"
            className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-[#9CAF88] outline-none"
          />
        </div>

        <Button type="submit" className="w-full py-6 text-lg bg-[#9CAF88] hover:bg-[#8b9c79]">
          <Save className="w-5 h-5 mr-2" /> Save Pet
        </Button>
      </form>
    </div>
  );
};

export default AddPetPage;
