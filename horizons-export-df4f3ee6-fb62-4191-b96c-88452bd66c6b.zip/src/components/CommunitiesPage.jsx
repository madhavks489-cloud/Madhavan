
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Hash, Users, Plus } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import ChannelView from './ChannelView';

const CommunitiesPage = () => {
  const [channels, setChannels] = useState([]);
  const [activeChannel, setActiveChannel] = useState(null);

  useEffect(() => {
    fetchChannels();
    // Realtime subscription
    const sub = supabase.channel('public:channels')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'channels' }, fetchChannels)
      .subscribe();
    return () => supabase.removeChannel(sub);
  }, []);

  const fetchChannels = async () => {
    const { data } = await supabase.from('channels').select('*');
    if (data) setChannels(data);
  };

  if (activeChannel) {
    return <ChannelView channel={activeChannel} onBack={() => setActiveChannel(null)} />;
  }

  return (
    <div className="container mx-auto px-4 py-6 max-w-2xl min-h-screen bg-[#FFF8F3]">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold font-poppins text-gray-900">Communities</h1>
        <Button variant="outline" className="border-[#9CAF88] text-[#9CAF88]">
          <Plus className="w-4 h-4 mr-1" /> Create
        </Button>
      </div>

      <div className="grid gap-4">
        {channels.map(channel => (
          <motion.div
            key={channel.id}
            onClick={() => setActiveChannel(channel)}
            whileHover={{ scale: 1.01 }}
            className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 cursor-pointer flex items-center justify-between"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-[#E0F2F1] rounded-full flex items-center justify-center text-[#9CAF88]">
                <Hash className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-lg text-gray-900">{channel.name}</h3>
                <p className="text-sm text-gray-500">{channel.description}</p>
              </div>
            </div>
            <Button size="sm" className="bg-[#9CAF88] hover:bg-[#869d73]">Join</Button>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default CommunitiesPage;
