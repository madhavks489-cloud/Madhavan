
import React, { useState, useEffect } from 'react';
import { Calendar, Trash2, Plus, Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';

const RemindersPanel = () => {
  const [reminders, setReminders] = useState([]);
  const [showAdd, setShowAdd] = useState(false);
  const [newReminder, setNewReminder] = useState({ title: '', date: '', type: 'vaccine' });
  const { toast } = useToast();

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem('pet_reminders') || '[]');
    setReminders(stored);
  }, []);

  const addReminder = (e) => {
    e.preventDefault();
    const reminder = {
      id: Date.now(),
      ...newReminder,
      completed: false
    };
    const updated = [...reminders, reminder].sort((a, b) => new Date(a.date) - new Date(b.date));
    setReminders(updated);
    localStorage.setItem('pet_reminders', JSON.stringify(updated));
    setShowAdd(false);
    toast({ title: "Reminder Added" });
  };

  const deleteReminder = (id) => {
    const updated = reminders.filter(r => r.id !== id);
    setReminders(updated);
    localStorage.setItem('pet_reminders', JSON.stringify(updated));
  };

  return (
    <div className="container mx-auto px-4 py-6 max-w-2xl">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold font-poppins">Pet Reminders</h1>
        <Button onClick={() => setShowAdd(!showAdd)} className="bg-[#9CAF88]">
          <Plus className="w-4 h-4 mr-2" /> Add
        </Button>
      </div>

      {showAdd && (
        <motion.form 
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          className="bg-white p-4 rounded-xl shadow-lg mb-6 space-y-4"
          onSubmit={addReminder}
        >
          <input 
            placeholder="Reminder Title (e.g. Rabies Shot)" 
            className="w-full p-2 border rounded"
            required
            value={newReminder.title}
            onChange={e => setNewReminder({...newReminder, title: e.target.value})}
          />
          <div className="flex gap-2">
            <input 
              type="date" 
              className="flex-1 p-2 border rounded"
              required
              value={newReminder.date}
              onChange={e => setNewReminder({...newReminder, date: e.target.value})}
            />
            <select 
              className="flex-1 p-2 border rounded"
              value={newReminder.type}
              onChange={e => setNewReminder({...newReminder, type: e.target.value})}
            >
              <option value="vaccine">Vaccine</option>
              <option value="medication">Medication</option>
              <option value="grooming">Grooming</option>
              <option value="vet">Vet Visit</option>
            </select>
          </div>
          <Button type="submit" className="w-full">Save Reminder</Button>
        </motion.form>
      )}

      <div className="space-y-3">
        {reminders.length === 0 ? (
           <div className="text-center py-10 text-gray-500 bg-white rounded-xl">
             <Bell className="w-12 h-12 mx-auto mb-2 text-[#B4D4FF]" />
             <p>No upcoming reminders.</p>
           </div>
        ) : (
          reminders.map(reminder => (
            <motion.div 
              key={reminder.id}
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              className="bg-white p-4 rounded-xl shadow flex items-center justify-between border-l-4 border-[#9CAF88]"
            >
              <div>
                <h3 className="font-bold">{reminder.title}</h3>
                <div className="flex items-center text-sm text-gray-500 gap-2">
                  <Calendar className="w-3 h-3" />
                  {new Date(reminder.date).toLocaleDateString()}
                  <span className="capitalize bg-gray-100 px-2 py-0.5 rounded text-xs">{reminder.type}</span>
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => deleteReminder(reminder.id)}
                className="text-red-400 hover:text-red-600 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
};

export default RemindersPanel;
