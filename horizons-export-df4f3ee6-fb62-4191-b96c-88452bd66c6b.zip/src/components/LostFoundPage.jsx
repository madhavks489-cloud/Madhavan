
import React, { useState } from 'react';
import { MapPin, AlertTriangle, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const LostFoundPage = ({ onBack }) => {
  const [status, setStatus] = useState('lost');
  const [petName, setPetName] = useState('');
  const [description, setDescription] = useState('');
  const [gettingLocation, setGettingLocation] = useState(false);
  const [location, setLocation] = useState(null);
  const { toast } = useToast();

  const handleGetLocation = () => {
    setGettingLocation(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setLocation({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude
          });
          setGettingLocation(false);
          toast({ title: "Location Acquired" });
        },
        () => {
          setGettingLocation(false);
          toast({ title: "Error getting location", variant: "destructive" });
        }
      );
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!location) {
      toast({ title: "Location required", description: "Please get your current location.", variant: "destructive" });
      return;
    }

    const newItem = {
      id: Date.now().toString(),
      status,
      pet_name: petName,
      description,
      latitude: location.lat,
      longitude: location.lng,
      created_at: new Date().toISOString()
    };

    const existingItems = JSON.parse(localStorage.getItem('paws_lost_found') || '[]');
    localStorage.setItem('paws_lost_found', JSON.stringify([...existingItems, newItem]));

    toast({
      title: "Report Submitted",
      description: "Your post has been added to the map.",
    });
    onBack();
  };

  return (
    <div className="container mx-auto px-4 py-6 max-w-md">
       <button onClick={onBack} className="mb-4 text-gray-500">Cancel</button>
       <h1 className="text-2xl font-bold mb-6">Report Lost/Found Pet</h1>

       <div className="flex gap-4 mb-6">
         <button 
           onClick={() => setStatus('lost')}
           className={`flex-1 p-4 rounded-xl border-2 flex flex-col items-center ${
             status === 'lost' ? 'border-red-500 bg-red-50 text-red-700' : 'border-gray-200'
           }`}
         >
           <AlertTriangle className="mb-2" /> Lost Pet
         </button>
         <button 
           onClick={() => setStatus('found')}
           className={`flex-1 p-4 rounded-xl border-2 flex flex-col items-center ${
             status === 'found' ? 'border-green-500 bg-green-50 text-green-700' : 'border-gray-200'
           }`}
         >
           <CheckCircle className="mb-2" /> Found Pet
         </button>
       </div>

       <form onSubmit={handleSubmit} className="space-y-4">
         <div>
           <label className="block text-sm font-medium mb-1">Pet Description / Name</label>
           <input 
             value={petName}
             onChange={e => setPetName(e.target.value)}
             className="w-full p-3 border rounded-lg"
             placeholder="e.g. Golden Retriever, answers to 'Max'"
             required
           />
         </div>

         <div>
           <label className="block text-sm font-medium mb-1">Details</label>
           <textarea 
             value={description}
             onChange={e => setDescription(e.target.value)}
             className="w-full p-3 border rounded-lg h-24"
             placeholder="Any distinctive marks, collar color, etc."
             required
           />
         </div>

         <div className="bg-gray-50 p-4 rounded-lg flex items-center justify-between">
           <div className="flex items-center gap-2">
             <MapPin className="text-gray-400" />
             <span className="text-sm text-gray-600">
               {location ? "Location Set" : "Location Required"}
             </span>
           </div>
           <Button 
             type="button" 
             onClick={handleGetLocation}
             disabled={gettingLocation || location}
             variant="outline"
             size="sm"
           >
             {gettingLocation ? "Locating..." : location ? "Update" : "Get Location"}
           </Button>
         </div>

         <Button type="submit" className="w-full py-6">Submit Report</Button>
       </form>
    </div>
  );
};

export default LostFoundPage;
