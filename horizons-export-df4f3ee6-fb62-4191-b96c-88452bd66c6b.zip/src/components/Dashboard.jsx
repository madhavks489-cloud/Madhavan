
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Bell } from 'lucide-react';
import BottomNav from '@/components/BottomNav';
import Feed from '@/components/Feed';
import MapView from '@/components/MapView';
import ForumPage from '@/components/ForumPage';
import MessagesPage from '@/components/MessagesPage';
import CommunitiesPage from '@/components/CommunitiesPage';
import QnAPage from '@/components/QnAPage';
import Profile from '@/components/Profile';
import NotificationCenter from '@/components/NotificationCenter';
import { useAuth } from '@/context/AuthContext';

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState('home');
  const [showNotifications, setShowNotifications] = useState(false);
  const { user } = useAuth();

  const renderContent = () => {
    switch (activeTab) {
      case 'home': return <Feed />;
      case 'messages': return <MessagesPage />;
      case 'communities': return <CommunitiesPage />;
      case 'qna': return <QnAPage />;
      case 'map': return <MapView />;
      case 'profile': return <Profile />;
      default: return <Feed />;
    }
  };

  return (
    <div className="min-h-screen bg-[#FFF8F3]">
      <Helmet><title>Paws & Pals</title></Helmet>
      
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 h-16 bg-white shadow-sm z-40 flex items-center justify-between px-4">
        <h1 className="text-xl font-bold font-poppins text-[#9CAF88]">Paws & Pals</h1>
        <button onClick={() => setShowNotifications(true)} className="relative p-2">
          <Bell className="w-6 h-6 text-gray-600" />
          <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white" />
        </button>
      </header>

      {/* Main Content */}
      <main className="pt-16 pb-24">
        {renderContent()}
      </main>

      <NotificationCenter isOpen={showNotifications} onClose={() => setShowNotifications(false)} />
      <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  );
};

export default Dashboard;
