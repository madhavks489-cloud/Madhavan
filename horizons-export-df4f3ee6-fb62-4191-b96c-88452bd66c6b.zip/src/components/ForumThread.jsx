
import React, { useState } from 'react';
import { ArrowLeft, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import VerifiedVetBadge from '@/components/VerifiedVetBadge';
import { useAuth } from '@/context/AuthContext';

const ForumThread = ({ threadId, onBack }) => {
  const { user } = useAuth();
  const [comment, setComment] = useState('');
  
  // Load thread data
  const threads = JSON.parse(localStorage.getItem('forum_threads') || '[]');
  const threadIndex = threads.findIndex(t => t.id === threadId);
  const thread = threads[threadIndex];
  const [localThread, setLocalThread] = useState(thread);

  const handleComment = (e) => {
    e.preventDefault();
    if (!comment.trim()) return;

    const newComment = {
      id: Date.now(),
      authorName: user?.name || 'Guest',
      content: comment,
      createdAt: new Date().toISOString(),
      isVet: user?.role === 'verified_vet'
    };

    const updatedThread = {
      ...localThread,
      comments: [...(localThread.comments || []), newComment]
    };

    setLocalThread(updatedThread);
    threads[threadIndex] = updatedThread;
    localStorage.setItem('forum_threads', JSON.stringify(threads));
    setComment('');
  };

  if (!thread) return <div>Thread not found</div>;

  return (
    <div className="container mx-auto px-4 py-6 max-w-2xl min-h-screen pb-24">
      <button onClick={onBack} className="flex items-center gap-2 mb-6 text-gray-600">
        <ArrowLeft className="w-5 h-5" /> Back
      </button>

      <div className="bg-white p-6 rounded-xl shadow-lg mb-6">
        <div className="flex justify-between items-start mb-4">
          <h1 className="text-xl font-bold">{thread.title}</h1>
          <span className="text-xs bg-gray-100 px-2 py-1 rounded">{thread.category}</span>
        </div>
        <div className="flex items-center gap-2 mb-4 text-sm text-gray-500">
           <span>{thread.authorName}</span>
           <span>•</span>
           <span>{new Date(thread.createdAt).toLocaleDateString()}</span>
        </div>
        <p className="text-gray-800 leading-relaxed whitespace-pre-wrap">{thread.content}</p>
      </div>

      <h3 className="font-bold mb-4">Comments ({localThread.comments?.length || 0})</h3>
      
      <div className="space-y-4 mb-20">
        {localThread.comments?.map(c => (
          <div key={c.id} className={`p-4 rounded-xl ${c.isVet ? 'bg-yellow-50 border border-yellow-200' : 'bg-white shadow-sm'}`}>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-sm">{c.authorName}</span>
                {c.isVet && <VerifiedVetBadge />}
              </div>
              <span className="text-xs text-gray-400">{new Date(c.createdAt).toLocaleDateString()}</span>
            </div>
            <p className="text-sm text-gray-700">{c.content}</p>
          </div>
        ))}
      </div>

      {/* Comment Input */}
      <div className="fixed bottom-0 left-0 right-0 bg-white p-4 border-t border-gray-200 z-40">
        <form onSubmit={handleComment} className="max-w-2xl mx-auto flex gap-2">
          <input 
            value={comment}
            onChange={e => setComment(e.target.value)}
            className="flex-1 p-3 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-[#9CAF88]"
            placeholder="Add a comment..."
          />
          <Button type="submit" size="icon" className="rounded-full bg-[#9CAF88]">
            <Send className="w-4 h-4" />
          </Button>
        </form>
      </div>
    </div>
  );
};

export default ForumThread;
