
import React, { useState, useEffect, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { getCurrentLocation } from '@/lib/geolocation';

// Fix icons
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const MapView = () => {
  const { user } = useAuth();
  const [position, setPosition] = useState(null);
  const [nearbyUsers, setNearbyUsers] = useState([]);

  useEffect(() => {
    if (!user) return;
    
    // 1. Get initial location
    getCurrentLocation().then(loc => {
      setPosition([loc.latitude, loc.longitude]);
      updateMyLocation(loc.latitude, loc.longitude);
    });

    // 2. Fetch initial nearby users
    fetchNearbyUsers();

    // 3. Subscribe to location updates
    const channel = supabase.channel('locations')
      .on('postgres_changes', { 
        event: 'UPDATE', 
        schema: 'public', 
        table: 'profiles',
        filter: 'location_enabled=eq.true'
      }, (payload) => {
        setNearbyUsers(prev => {
          const others = prev.filter(u => u.id !== payload.new.id);
          return [...others, payload.new];
        });
      })
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, [user]);

  const updateMyLocation = async (lat, lng) => {
    await supabase.from('profiles').update({ 
      latitude: lat, 
      longitude: lng, 
      location_enabled: true,
      last_seen: new Date()
    }).eq('id', user.id);
  };

  const fetchNearbyUsers = async () => {
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .eq('location_enabled', true)
      .neq('id', user.id); // Exclude self
    if (data) setNearbyUsers(data);
  };

  if (!position) return <div className="h-screen flex items-center justify-center">Loading Map...</div>;

  return (
    <div className="h-[calc(100vh-140px)] w-full relative">
      <MapContainer center={position} zoom={14} style={{ height: '100%', width: '100%' }}>
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        
        {/* Me */}
        <Marker position={position}>
          <Popup>You</Popup>
        </Marker>
        <Circle center={position} radius={500} pathOptions={{ fillColor: '#9CAF88', color: '#9CAF88' }} />

        {/* Others */}
        {nearbyUsers.map(u => (
          u.latitude && u.longitude && (
            <Circle 
              key={u.id}
              center={[u.latitude, u.longitude]}
              radius={300}
              pathOptions={{ 
                fillColor: u.role === 'verified_vet' ? '#D4AF37' : '#87CEEB', 
                color: u.role === 'verified_vet' ? '#D4AF37' : '#87CEEB' 
              }}
            >
              <Popup>{u.full_name} ({u.role})</Popup>
            </Circle>
          )
        ))}
      </MapContainer>
    </div>
  );
};

export default MapView;
