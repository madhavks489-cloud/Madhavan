
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, MessageCircle, User } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import MessageThread from './MessageThread';

const MessagesPage = () => {
  const { user } = useAuth();
  const [conversations, setConversations] = useState([]);
  const [activeConversation, setActiveConversation] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    if (!user) return;
    fetchConversations();
    
    // Subscribe to new messages to update preview
    const channel = supabase
      .channel('public:messages')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, () => {
        fetchConversations();
      })
      .subscribe();

    return () => supabase.removeChannel(channel);
  }, [user]);

  const fetchConversations = async () => {
    // Complex query to get conversations and last message info
    // For prototype, we'll fetch conversations first
    const { data: parts, error } = await supabase
      .from('conversation_participants')
      .select('conversation_id')
      .eq('user_id', user.id);

    if (error || !parts) return;

    const convIds = parts.map(p => p.conversation_id);
    
    // Fetch details
    // Note: In a production app, this would be a View or a joined query
    const convs = [];
    for (const id of convIds) {
      const { data: msgs } = await supabase
        .from('messages')
        .select('*')
        .eq('conversation_id', id)
        .order('created_at', { ascending: false })
        .limit(1);

      const { data: participants } = await supabase
        .from('conversation_participants')
        .select('profiles:user_id(full_name, avatar_url)')
        .eq('conversation_id', id)
        .neq('user_id', user.id)
        .single();
      
      if (participants) {
        convs.push({
          id,
          otherUser: participants.profiles,
          lastMessage: msgs?.[0] || { content: 'New conversation' },
          timestamp: msgs?.[0]?.created_at
        });
      }
    }
    
    setConversations(convs.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)));
  };

  if (activeConversation) {
    return <MessageThread conversation={activeConversation} onBack={() => setActiveConversation(null)} />;
  }

  return (
    <div className="container mx-auto px-4 py-6 max-w-2xl min-h-screen bg-[#FFF8F3]">
      <h1 className="text-3xl font-bold mb-6 font-poppins text-gray-900">Messages</h1>
      
      <div className="relative mb-6">
        <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
        <input 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search conversations..."
          className="w-full pl-10 p-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-[#9CAF88] focus:outline-none"
        />
      </div>

      <div className="space-y-2">
        {conversations.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <MessageCircle className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>No messages yet.</p>
          </div>
        ) : (
          conversations.map(conv => (
            <motion.div
              key={conv.id}
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveConversation(conv)}
              className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center gap-4 cursor-pointer"
            >
              <div className="relative">
                {conv.otherUser.avatar_url ? (
                  <img src={conv.otherUser.avatar_url} alt="" className="w-12 h-12 rounded-full object-cover" />
                ) : (
                  <div className="w-12 h-12 bg-[#9CAF88] rounded-full flex items-center justify-center text-white">
                    <User className="w-6 h-6" />
                  </div>
                )}
                {/* Online indicator could go here */}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-baseline mb-1">
                  <h3 className="font-bold text-gray-900 truncate">{conv.otherUser.full_name}</h3>
                  <span className="text-xs text-gray-400 whitespace-nowrap">
                    {new Date(conv.timestamp).toLocaleDateString()}
                  </span>
                </div>
                <p className="text-sm text-gray-600 truncate">{conv.lastMessage.content}</p>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
};

export default MessagesPage;
