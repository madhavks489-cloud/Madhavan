
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, CheckCircle, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/context/AuthContext';

const VetApplicationForm = ({ onBack }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    regNumber: '',
    university: '',
    gradYear: '',
  });
  const { toast } = useToast();
  const { user } = useAuth();

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleFileUpload = (e) => {
    // In a real app, upload to Supabase Storage here
    toast({
      title: "File Uploaded",
      description: "Document successfully attached.",
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Simulate API call to Supabase
    const application = {
      id: Date.now().toString(),
      userId: user.id,
      ...formData,
      status: 'pending',
      submittedAt: new Date().toISOString()
    };

    const existingApps = JSON.parse(localStorage.getItem('vet_applications') || '[]');
    localStorage.setItem('vet_applications', JSON.stringify([...existingApps, application]));

    setStep(2); // Success state
  };

  if (step === 2) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-lg text-center">
         <motion.div 
           initial={{ scale: 0.8, opacity: 0 }}
           animate={{ scale: 1, opacity: 1 }}
           className="bg-white rounded-3xl p-8 shadow-xl"
         >
           <CheckCircle className="w-16 h-16 text-[#9CAF88] mx-auto mb-4" />
           <h2 className="text-2xl font-bold mb-2">Application Submitted!</h2>
           <p className="text-gray-600 mb-6">
             Your reference number is <span className="font-mono font-bold">#{Date.now().toString().slice(-6)}</span>
           </p>
           <p className="text-sm text-gray-500 mb-8">
             We will review your documents and verify your credentials within 2-3 business days. You will receive an email update.
           </p>
           <Button onClick={onBack} className="w-full bg-[#B4D4FF] text-gray-900">
             Return to Profile
           </Button>
         </motion.div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6 max-w-lg">
      <button onClick={onBack} className="flex items-center gap-2 mb-6 text-gray-600">
        <ArrowLeft className="w-5 h-5" /> Back
      </button>

      <h1 className="text-2xl font-bold mb-6 font-poppins">Veterinarian Verification</h1>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="bg-white p-6 rounded-xl shadow-lg space-y-4">
          <h2 className="font-bold text-lg text-gray-900">Professional Details</h2>
          
          <div>
            <label className="block text-sm font-medium mb-1">Legal Name</label>
            <input 
              name="fullName"
              required
              value={formData.fullName}
              onChange={handleInputChange}
              className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-[#9CAF88] outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Veterinary Registration Number</label>
            <input 
              name="regNumber"
              required
              value={formData.regNumber}
              onChange={handleInputChange}
              className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-[#9CAF88] outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">University / College</label>
            <input 
              name="university"
              required
              value={formData.university}
              onChange={handleInputChange}
              className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-[#9CAF88] outline-none"
            />
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-lg space-y-4">
          <h2 className="font-bold text-lg text-gray-900">Documents</h2>
          <p className="text-sm text-gray-500">Upload PDF or JPG (Max 5MB)</p>
          
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:bg-gray-50 transition cursor-pointer relative">
            <input type="file" onChange={handleFileUpload} className="absolute inset-0 opacity-0 cursor-pointer" />
            <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
            <span className="text-sm font-medium text-gray-600">Upload Degree Certificate</span>
          </div>

          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:bg-gray-50 transition cursor-pointer relative">
            <input type="file" onChange={handleFileUpload} className="absolute inset-0 opacity-0 cursor-pointer" />
            <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
            <span className="text-sm font-medium text-gray-600">Upload Government ID</span>
          </div>
        </div>

        <Button type="submit" className="w-full py-6 text-lg bg-[#9CAF88] hover:bg-[#8b9c79]">
          Submit Application
        </Button>
      </form>
    </div>
  );
};

export default VetApplicationForm;
