
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import LandingPage from '@/components/LandingPage';
import Dashboard from '@/components/Dashboard';
import LoginPage from '@/components/auth/LoginPage';
import SignupPage from '@/components/auth/SignupPage';
import { Toaster } from '@/components/ui/toaster';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import VetVerificationDashboard from '@/components/admin/VetVerificationDashboard';
import VetApplicationForm from '@/components/VetApplicationForm';

const AppContent = () => {
  const { user, loading } = useAuth();
  const [authMode, setAuthMode] = useState('login');
  const [hasVisitedLanding, setHasVisitedLanding] = useState(false);
  
  // Simple routing for admin/vet pages (since we don't use React Router in this restricted setup effectively without rewrite)
  // We hijack the dashboard for specific roles or states if needed, but for now we stick to the main dashboard
  // and render overlays/pages based on state if we wanted full routing. 
  // However, standard React Router is permitted. 
  // The system prompt allows React Router 6.16.0.
  // BUT the current App.jsx structure uses conditional rendering. 
  // I will stick to the existing structure for consistency but add a check for "admin" mode.
  
  const [currentView, setCurrentView] = useState('default'); // default, vet-app, admin

  if (loading) return <div className="h-screen flex items-center justify-center bg-[#FFF8F3]"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#9CAF88]"></div></div>;

  if (!hasVisitedLanding) {
    return <LandingPage onEnter={() => setHasVisitedLanding(true)} />;
  }

  if (!user) {
    return authMode === 'login' ? (
      <LoginPage onToggleMode={() => setAuthMode('signup')} />
    ) : (
      <SignupPage onToggleMode={() => setAuthMode('login')} />
    );
  }

  // Admin Route Simulation
  if (user.role === 'admin' && currentView === 'admin') {
     return <VetVerificationDashboard onBack={() => setCurrentView('default')} />;
  }
  
  // Just pass currentView setter to Dashboard to allow navigation to full pages if needed
  return <Dashboard onNavigate={(view) => setCurrentView(view)} currentView={currentView} />;
};

function App() {
  return (
    <AuthProvider>
      <Helmet>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />
      </Helmet>
      
      <AppContent />
      <Toaster />
    </AuthProvider>
  );
}

export default App;
