
// Data is now managed via localStorage/Context to simulate a real backend
// This file is kept empty to ensure no dummy data is used

export const dummyPets = [];
export const dummyFeedPosts = [];
export const dummyExpertPosts = [];
export const dummyHealthDocs = {};
export const aiSampleResponses = {};
